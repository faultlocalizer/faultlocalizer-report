c[10] += 1
print("Inputs: ", x, y, z)
rxy = multiply_xy(x, y)
if(rxy==0):
    return 0
else:
    c[7] += 1
    rxyz = multiply_rxy_z(rxy, z)
    print("multiply done", rxyz)
return rxyz
