from src.utils import Count 

def display_type_code(n):
    Count.incC(18)
    if n:
        Count.incC(1)
        return n
