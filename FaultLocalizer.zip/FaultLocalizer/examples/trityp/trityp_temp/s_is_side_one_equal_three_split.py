c[21] += 1
if type_code >= 0:
    c[4] += 1
    type_code = type_code + 2
    return type_code
