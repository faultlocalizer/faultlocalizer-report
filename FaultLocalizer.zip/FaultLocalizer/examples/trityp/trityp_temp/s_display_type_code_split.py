c[18] += 1
if n:
    c[1] += 1
    return n
